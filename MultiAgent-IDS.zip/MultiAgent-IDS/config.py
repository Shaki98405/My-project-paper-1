"""
config.py
Global configuration file for Multi-Agent Federated UAV-IDS
"""

import torch

CFG = {
    # File paths
    "data_raw": "data_raw/T-ITS_Dataset.csv",
    "data_preprocessed": "data_preprocessed/",
    "models_path": "models/",
    "results_path": "results/",

    # Dataset parameters
    "num_clients": 5,
    "input_dim": 38,          # T-ITS extracted features
    "num_classes": 5,

    # Hybrid AE–LSTM Model Parameters
    "ae_latent": 32,
    "lstm_units": 128,

    # Training
    "local_epochs": 50,
    "batch_size": 64,
    "lr": 0.001,
    "fed_rounds": 12,

    # Federated aggregation settings
    "aggregation": "fedavg",

    # Reproducibility
    "seed": 42,

    # Compute Device
    "device": "cuda" if torch.cuda.is_available() else "cpu"
}
