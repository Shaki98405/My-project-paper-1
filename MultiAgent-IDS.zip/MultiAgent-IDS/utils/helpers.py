"""
helpers.py
General helper utilities for the Multi-Agent Federated UAV-IDS system
"""

import os
import random
import numpy as np
import torch
from config import CFG


# -------------------------------------------------------------
# Set reproducibility seed
# -------------------------------------------------------------
def set_global_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    print(f"[INFO] Global seed set to {seed}")


# -------------------------------------------------------------
# Create required directories
# -------------------------------------------------------------
def create_required_dirs():
    dirs = [
        CFG["data_preprocessed"],
        CFG["models_path"],
        CFG["results_path"],
        "figures_ieee_tce",
        "edge_nodes",
        "uav_aggregator",
        "utils"
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    print("[INFO] Required directories created.")


# -------------------------------------------------------------
# Save PyTorch model state
# -------------------------------------------------------------
def save_model(model, path):
    torch.save(model.state_dict(), path)
    print(f"[INFO] Model saved to: {path}")


# -------------------------------------------------------------
# Load model weights
# -------------------------------------------------------------
def load_model(model, path, device):
    model.load_state_dict(torch.load(path, map_location=device))
    print(f"[INFO] Model loaded from: {path}")
    return model
