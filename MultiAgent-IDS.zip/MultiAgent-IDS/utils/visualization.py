"""
visualization.py
Visualization utilities for Multi-Agent Federated UAV-IDS
IEEE TCE-quality figures (800 DPI)
"""

import matplotlib.pyplot as plt
import numpy as np
import os


# -------------------------------------------------------------
# Accuracy–Loss Plot (Local Training)
# -------------------------------------------------------------
def plot_accuracy_loss(acc, loss, save_path="figures_ieee_tce/Fig_Training.png"):
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.figure(figsize=(5.2, 3))

    epochs = np.arange(1, len(acc) + 1)

    plt.plot(epochs, acc, label="Accuracy", color="#0077B6", linewidth=2)
    plt.plot(epochs, loss, label="Loss", color="#F59E0B", linestyle="--", linewidth=2)

    plt.xlabel("Epochs")
    plt.ylabel("Value")
    plt.ylim(0, 1.1)
    plt.legend()
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()

    plt.savefig(save_path, dpi=800, bbox_inches="tight")
    plt.close()
    print(f"[INFO] Saved: {save_path}")


# -------------------------------------------------------------
# Federated Convergence Plot
# -------------------------------------------------------------
def plot_federated_convergence(global_acc, edge_acc, save_path="figures_ieee_tce/Fig_FedConvergence.png"):
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.figure(figsize=(5.2, 3))

    rounds = np.arange(1, len(global_acc) + 1)

    # Plot edge clients
    for node, acc in edge_acc.items():
        plt.plot(rounds, acc, linestyle="--", linewidth=1.8,
                 label=f"Edge {node}")

    # Plot global model
    plt.plot(rounds, global_acc, linewidth=2.6, color="#F59E0B",
             label="Global Model")

    plt.xlabel("Federated Rounds")
    plt.ylabel("Accuracy (%)")
    plt.ylim(min(global_acc)-1, 100)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend(fontsize=8)
    plt.tight_layout()

    plt.savefig(save_path, dpi=800, bbox_inches="tight")
    plt.close()
    print(f"[INFO] Saved: {save_path}")


# -------------------------------------------------------------
# SHAP Feature Impact (Top-10)
# -------------------------------------------------------------
def plot_shap_importance(features, shap_values, save_path="figures_ieee_tce/Fig_SHAP.png"):
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.figure(figsize=(5.2, 3))

    percent = 100 * shap_values / shap_values.sum()
    colors = [plt.cm.coolwarm(i) for i in np.linspace(0.2, 0.9, len(features))]

    plt.barh(features[::-1], shap_values[::-1],
             color=colors[::-1], edgecolor="black")
    
    # Annotate %
    for i, val in enumerate(shap_values[::-1]):
        plt.text(val + max(shap_values)*0.02,
                 i, f"{percent[::-1][i]:.1f}%",
                 verticalalignment="center", fontsize=7)

    plt.xlabel("Mean |SHAP Value|")
    plt.ylabel("Top Features")
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()

    plt.savefig(save_path, dpi=800, bbox_inches="tight")
    plt.close()
    print(f"[INFO] Saved: {save_path}")


# -------------------------------------------------------------
# Comparison Bar Chart (Baseline Models vs Proposed)
# -------------------------------------------------------------
def plot_model_comparison(models, scores, metrics, save_path="figures_ieee_tce/Fig_Comparison.png"):
    plt.figure(figsize=(8, 4.2))

    num_metrics = len(metrics)
    num_models = len(models)

    x = np.arange(num_metrics)
    bar_width = 0.75 / num_models

    colors = ["#0077B6", "#00B4D8", "#90E0EF", "#F59E0B", "#E85D04", "#D00000"]

    for i in range(num_models):
        plt.bar(x + i*bar_width, scores[i], width=bar_width,
                color=colors[i], edgecolor="black", label=models[i])

    plt.xticks(x + bar_width*(num_models/2), metrics)
    plt.ylabel("Score (%)")
    plt.ylim(90, 100.5)
    plt.grid(axis="y", linestyle="--", alpha=0.4)
    plt.legend(fontsize=8, ncol=3)

    plt.tight_layout()
    plt.savefig(save_path, dpi=800, bbox_inches="tight")
    plt.close()
    print(f"[INFO] Saved: {save_path}")
