```
# Multi-Agent Federated Edge UAV-IDS (Hybrid AE–LSTM)
This repository contains the implementation of the Multi-Agent Federated Edge Intrusion Detection System (UAV-IDS) proposed in our IEEE TCE paper. The system integrates a hybrid Autoencoder–LSTM model with a UAV-assisted federated learning workflow for Smart City IoT security.

## Project Structure
- `main.py` – Runs the complete pipeline (data → local training → federated aggregation → evaluation).
- `config.py` – Global configuration, hyperparameters, and file paths.
- `data_preprocessing.py` – T-ITS dataset loading, cleaning, scaling, and zone-wise partitioning.
- `model_hybrid_ae_lstm.py` – Hybrid AE–LSTM model architecture.
- `edge_agent.py` – Multi-agent IDS for each edge node (traffic, anomaly, classification agents).
- `federated_uav.py` – UAV-based federated aggregation using FedAvg.
- `evaluation_metrics.py` – Computes accuracy, precision, recall, F1-score, MCC, Kappa and confusion matrix.
- `utils/helpers.py` – Reproducibility, directory setup, model I/O utilities.
- `utils/visualization.py` – Accuracy-loss curves, federated convergence, SHAP importance, and model comparison plots.
- `data_raw/` – Raw T-ITS dataset.
- `data_preprocessed/` – Processed and zone-partitioned datasets.
- `results/` – Evaluation metrics and generated figures.

## Requirements
Python 3.8+  
PyTorch, NumPy, Pandas, scikit-learn, imbalanced-learn, Matplotlib, Seaborn, SHAP, Flower (FL)

## How to Run
```

python main.py

```

## Output
- Trained global federated AE–LSTM model  
- Local edge model snapshots  
- Evaluation metrics (JSON)  
- Confusion matrix and all result figures (800 DPI)  
- Federated convergence and SHAP explainability plots  
```