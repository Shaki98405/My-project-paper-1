"""
model_hybrid_ae_lstm.py
Defines Autoencoder + LSTM hybrid model
"""

import torch
import torch.nn as nn


class Autoencoder(nn.Module):
    def __init__(self, input_dim, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, latent_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.ReLU(),
            nn.Linear(64, input_dim),
        )

    def forward(self, x):
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon, z


class HybridAELSTM(nn.Module):
    def __init__(self, input_dim, ae_latent, lstm_units, num_classes):
        super().__init__()

        self.ae = Autoencoder(input_dim, ae_latent)

        self.lstm = nn.LSTM(
            input_size=ae_latent,
            hidden_size=lstm_units,
            batch_first=True
        )

        self.classifier = nn.Sequential(
            nn.Linear(lstm_units, 128),
            nn.ReLU(),
            nn.Linear(128, num_classes)
        )

    def forward(self, x_seq):
        # x_seq shape: (batch, timesteps, features)
        batch, seq, feat = x_seq.size()
        x_flat = x_seq.reshape(-1, feat)

        recon, embedding = self.ae(x_flat)
        z_seq = embedding.reshape(batch, seq, -1)

        lstm_out, _ = self.lstm(z_seq)
        final_feat = lstm_out[:, -1, :]  # last timestep
        logits = self.classifier(final_feat)

        return logits, recon
