"""
edge_agent.py
Defines Multi-Agent IDS for each edge node
"""

import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from config import CFG


class TrafficAnalysisAgent:
    def preprocess(self, df):
        X = df.drop("class", axis=1).values
        y = df["class"].values
        return X, y


class AnomalyDetectionAgent:
    def compute_reconstruction_loss(self, recon, original):
        return torch.mean((recon - original)**2)


class AttackClassificationAgent:
    def __init__(self, num_classes):
        self.ce = nn.CrossEntropyLoss()


class EdgeNode:
    def __init__(self, name, df):
        self.name = name
        self.df = df
        self.traffic_agent = TrafficAnalysisAgent()
        self.anomaly_agent = AnomalyDetectionAgent()
        self.class_agent = AttackClassificationAgent(CFG["num_classes"])

        X, y = self.traffic_agent.preprocess(df)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.2, random_state=CFG["seed"]
        )

    # Local training
    def local_train(self, global_model):
        model = global_model
        model.train()
        optimizer = optim.Adam(model.parameters(), lr=CFG["lr"])

        X = torch.tensor(self.X_train, dtype=torch.float32).to(CFG["device"])
        y = torch.tensor(self.y_train, dtype=torch.long).to(CFG["device"])

        X = X.reshape(X.shape[0], 1, -1)  # single timestep

        for _ in range(CFG["local_epochs"]):
            optimizer.zero_grad()
            logits, recon = model(X)
            loss_cls = self.class_agent.ce(logits, y)
            loss_rec = self.anomaly_agent.compute_reconstruction_loss(
                recon, X.reshape(X.shape[0], -1)
            )
            loss = loss_cls + 0.3 * loss_rec
            loss.backward()
            optimizer.step()

        return model.state_dict(), len(self.X_train)

    def update_model(self, new_weights):
        for key, val in new_weights.items():
            new_weights[key] = val.clone()
        self.model_state = new_weights

