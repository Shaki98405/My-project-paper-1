"""
data_preprocessing.py
Handles T-ITS dataset cleaning, feature scaling, and zone partitioning
"""

import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from config import CFG


def load_and_partition_dataset(n_partitions=5):

    df = pd.read_csv("UAV_IDS_Federated/data_raw/T-ITS_Dataset.csv")

    # Drop missing values
    df = df.dropna()

    # Normalize numerical features
    scaler = MinMaxScaler()
    features = df.drop(columns=["class"])
    labels = df["class"]

    scaled = scaler.fit_transform(features)
    df_scaled = pd.DataFrame(scaled, columns=features.columns)
    df_scaled["class"] = labels.values

    # SMOTE for class balancing
    sm = SMOTE(random_state=CFG["seed"])
    X_res, y_res = sm.fit_resample(df_scaled.drop("class", axis=1),
                                   df_scaled["class"])
    df_resampled = pd.DataFrame(X_res, columns=df_scaled.columns[:-1])
    df_resampled["class"] = y_res

    # Partition into zones (non-IID)
    partitions = np.array_split(df_resampled.sample(frac=1), n_partitions)

    zone_map = {}
    for i, part in enumerate(partitions):
        zone_name = f"Zone-{chr(65+i)}"
        save_path = os.path.join(CFG["data_preprocessed"], f"{zone_name}.csv")
        part.to_csv(save_path, index=False)
        zone_map[zone_name] = part

    return zone_map
