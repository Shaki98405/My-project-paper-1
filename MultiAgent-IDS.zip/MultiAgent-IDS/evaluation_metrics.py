"""
evaluation_metrics.py
Computes Accuracy, Precision, Recall, F1, MCC, Kappa and Confusion Matrix
"""

import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    matthews_corrcoef, cohen_kappa_score, confusion_matrix
)
from config import CFG


def evaluate_global_model(model, df):
    model.eval()

    X = torch.tensor(df.drop("class", axis=1).values,
                     dtype=torch.float32).to(CFG["device"])
    y = df["class"].values

    X = X.reshape(X.shape[0], 1, -1)
    logits, _ = model(X)
    y_pred = torch.argmax(logits, dim=1).cpu().numpy()

    acc = accuracy_score(y, y_pred)
    pre = precision_score(y, y_pred, average="macro")
    rec = recall_score(y, y_pred, average="macro")
    f1 = f1_score(y, y_pred, average="macro")
    mcc = matthews_corrcoef(y, y_pred)
    kappa = cohen_kappa_score(y, y_pred)

    return acc, pre, rec, f1, mcc, kappa


def save_confusion_matrix(model, df, save_path):
    model.eval()

    X = torch.tensor(df.drop("class", axis=1).values,
                     dtype=torch.float32).to(CFG["device"])
    y = df["class"].values

    X = X.reshape(X.shape[0], 1, -1)
    logits, _ = model(X)
    preds = torch.argmax(logits, dim=1).cpu().numpy()

    cm = confusion_matrix(y, preds)

    plt.figure(figsize=(5, 4))
    plt.imshow(cm, cmap="Blues")
    plt.title("Confusion Matrix")
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.colorbar()
    plt.savefig(save_path, dpi=400, bbox_inches="tight")
    plt.close()
