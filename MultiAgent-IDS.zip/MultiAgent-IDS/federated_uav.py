"""
federated_uav.py
Simulates UAV-based Federated Aggregation
"""

import copy
import torch
from config import CFG


class UAVAggregator:
    def __init__(self, model, num_clients, rounds, device):
        self.global_model = model
        self.num_clients = num_clients
        self.rounds = rounds
        self.device = device

    def aggregate(self, client_weights, data_sizes):
        new_state = copy.deepcopy(client_weights[0])

        total_data = sum(data_sizes)

        for key in new_state.keys():
            new_state[key] = sum(
                (client_weights[i][key] * data_sizes[i] / total_data)
                for i in range(len(client_weights))
            ).clone()

        self.global_model.load_state_dict(new_state)
        return new_state
