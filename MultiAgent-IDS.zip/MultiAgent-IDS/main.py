"""
main.py
===========
Entry point for Multi-Agent Federated Edge UAV-IDS (Hybrid AE–LSTM)
Used for IEEE TCE Supplementary Material Submission
"""

import os
import json
import torch
import numpy as np
import pandas as pd

# Local modules
from config import CFG
from data_preprocessing import load_and_partition_dataset
from model_hybrid_ae_lstm import HybridAELSTM
from edge_agent import EdgeNode
from federated_uav import UAVAggregator
from evaluation_metrics import evaluate_global_model, save_confusion_matrix
from utils.helpers import set_global_seed, create_required_dirs


# ============================================================
#               MAIN PIPELINE FUNCTION
# ============================================================

def run_federated_pipeline():

    print("\n============================================")
    print(" Multi-Agent Federated UAV-IDS System – Start")
    print("============================================\n")

    # --------------------------------------------------------
    # 1. Environment Setup
    # --------------------------------------------------------
    set_global_seed(CFG['seed'])
    create_required_dirs()

    print("[1] Environment setup completed.")

    # --------------------------------------------------------
    # 2. Load & Partition Dataset (T-ITS)
    # --------------------------------------------------------
    zone_data = load_and_partition_dataset(
        file_path=CFG['data_raw'],
        n_partitions=CFG['num_clients']
    )

    print("[2] Dataset loaded and partitioned into zones:",
          list(zone_data.keys()))

    # --------------------------------------------------------
    # 3. Initialize Edge Nodes + Multi-Agent System
    # --------------------------------------------------------
    edge_nodes = {}
    for zone_name, df_zone in zone_data.items():
        node = EdgeNode(zone_name, df_zone)
        edge_nodes[zone_name] = node

    print(f"[3] Initialized {len(edge_nodes)} edge nodes with multi-agent IDS.")

    # --------------------------------------------------------
    # 4. Initialize Global Hybrid AE–LSTM Model
    # --------------------------------------------------------
    global_model = HybridAELSTM(
        input_dim=CFG['input_dim'],
        ae_latent=CFG['ae_latent'],
        lstm_units=CFG['lstm_units'],
        num_classes=CFG['num_classes']
    )

    print("[4] Global hybrid AE–LSTM model initialized.")

    # --------------------------------------------------------
    # 5. Initialize UAV Federated Aggregator
    # --------------------------------------------------------
    uav = UAVAggregator(
        model=global_model,
        num_clients=CFG['num_clients'],
        rounds=CFG['fed_rounds'],
        device=CFG['device']
    )

    print("[5] UAV Aggregator initialized with FedAvg protocol.")

    # --------------------------------------------------------
    # 6. Federated Training Loop
    # --------------------------------------------------------
    print("\nStarting Federated Learning...\n")

    for r in range(CFG['fed_rounds']):
        print(f"---- Federated Round {r+1}/{CFG['fed_rounds']} ----")

        client_weights = []
        client_sizes = []

        # Local training at each edge node
        for zone_name, node in edge_nodes.items():
            w, n = node.local_train(global_model)
            client_weights.append(w)
            client_sizes.append(n)

        # UAV Aggregator performs FedAvg
        updated_weights = uav.aggregate(client_weights, client_sizes)

        # Broadcast new global weights to all clients
        for node in edge_nodes.values():
            node.update_model(updated_weights)

        print(f"Round {r+1} completed.\n")

    print("[6] Federated training completed successfully.")

    # --------------------------------------------------------
    # 7. Evaluate Global Model on Combined Test Data
    # --------------------------------------------------------
    full_test_data = pd.concat([node.test_df for node in edge_nodes.values()])
    accuracy, precision, recall, f1, mcc, kappa = evaluate_global_model(
        global_model, full_test_data
    )

    print("\n[7] Global Model Evaluation:")
    print(f"   Accuracy  : {accuracy:.4f}")
    print(f"   Precision : {precision:.4f}")
    print(f"   Recall    : {recall:.4f}")
    print(f"   F1-Score  : {f1:.4f}")
    print(f"   MCC       : {mcc:.4f}")
    print(f"   Kappa     : {kappa:.4f}")

    # Save confusion matrix
    save_confusion_matrix(global_model, full_test_data,
                          save_path="results/confusion_matrix.png")

    # --------------------------------------------------------
    # 8. Save Results
    # --------------------------------------------------------
    results = {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
        "mcc": mcc,
        "kappa": kappa
    }

    with open("results/metrics_summary.json", "w") as f:
        json.dump(results, f, indent=4)

    torch.save(global_model.state_dict(), "models/global_fed_model.pt")

    print("\n[8] Results saved to 'results/' and model saved in 'models/'.")
    print("\n============================================")
    print(" Multi-Agent Federated UAV-IDS System – End")
    print("============================================\n")


# ============================================================
#               MAIN EXECUTION CALL
# ============================================================

if __name__ == "__main__":
    run_federated_pipeline()
